# How to start as Library

1. [About](guide/about.md)
2. [Lifecycle](guide/lifecycle.md)
3. [New Application](guide/app.md)
4. [Examples](guide/examples.md)
5. [Additional](guide/additional.md)
