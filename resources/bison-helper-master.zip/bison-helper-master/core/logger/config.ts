export interface ILoggerConfig {
  debug: boolean
  info: boolean
  warn: boolean
}
