export interface IHttpServerConfig {
  port: number
  host: string
}
