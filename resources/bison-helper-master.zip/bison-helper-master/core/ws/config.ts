export interface IWSConfig {
  port: number
  keepalive: number
  path?: string
}
