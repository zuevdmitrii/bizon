export interface IRedisConfig {
  host: string
  port: number
  db: number
}
