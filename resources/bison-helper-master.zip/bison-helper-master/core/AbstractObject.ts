/**
 * @deprecated
 */
export interface AbstractObject {
  [K: string]: any
}
