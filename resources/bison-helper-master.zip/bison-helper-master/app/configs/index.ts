import { defaults } from './defaults'
import { ISettings } from './SettingsInterface'

export const settings: ISettings = { ...defaults }
